//
//  MyView.h
//  Window
//
//  Created by ASTROMEDICOMP on 25/05/18.
//

#import <UIKit/UIKit.h>

@interface MyView : UIView <UIGestureRecognizerDelegate>

@end
